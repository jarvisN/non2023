function goToNextPage() {
    // Redirect to another page
    window.location.href = 'testpage.html';
}

function backToHomePage(){
    window.location.href = 'index.html';
}